import React from 'react';

const SimpleTest = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Test Component</h1>
      <p>If you can see this, React is working.</p>
    </div>
  );
};

export default SimpleTest;
